describe('Support API:', function () {
    describe('#isSupportWebP()', function () {
        it(`outils.isSupportWebP() should return true`, function () {
            assert(outils.isSupportWebP())
        });
    });
})